import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <p>lazy1 component loaded</p>
  `
})
export class Lazy1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
