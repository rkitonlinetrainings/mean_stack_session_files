import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <p> lazy2a component loaded </p>
  `
})
export class Lazy2aComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
