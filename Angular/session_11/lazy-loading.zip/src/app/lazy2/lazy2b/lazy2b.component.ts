import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <p> lazy2b component loaded </p>
  `
})
export class Lazy2bComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
