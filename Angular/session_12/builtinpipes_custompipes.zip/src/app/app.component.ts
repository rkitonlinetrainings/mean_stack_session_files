import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	title = 'pipesinangular';
  
	userName: string = "anDreEs wIlliaMs";
	arr1: any[] = [45, 74, 49, 88, 44];
	pi: number = Math.PI;
	salary: number = 6373.44;
	person = {
		firstName: "angyu", 
		lastName: "bhuo"
	}
	createdAt = new Date();
	status: boolean = true;
	
}
