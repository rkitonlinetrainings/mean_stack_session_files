import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "capitalize"
})

export class CapitalizePipe implements PipeTransform {
	transform(value: string, todos: boolean = true): any {
		// value = anDreEs wIlliaMs
		value = value.toLowerCase();
		// value = andrees williams
		let nums = value.split(" ");
		// value[0] = "andreas"
		// value[1] = "williams"
		
		if(todos) {
			for(let i in nums) {
				nums[i] = nums[i][0].toUpperCase() + nums[i].substring(1);
			}
		} else {
			nums[0] = nums[0][0].toUpperCase() + nums[0].substr(1);
		}
		
		return nums.join(" ");
	}
}