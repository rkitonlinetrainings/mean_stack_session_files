import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RoundBlockDirective } from './round-block.directive';
import { RoundBlock1Directive } from './round-block1.directive';
import { AboutusComponent } from './aboutus/aboutus.component';

@NgModule({
  declarations: [
    AppComponent, 
	RoundBlockDirective, AboutusComponent, RoundBlock1Directive
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent, AboutusComponent]
})
export class AppModule { }
