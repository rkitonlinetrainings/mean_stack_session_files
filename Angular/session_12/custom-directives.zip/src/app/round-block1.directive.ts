import { Directive, ElementRef, Input, Renderer2, OnInit } from "@angular/core";

@Directive({
	selector: '[appRoundBlock1]'
})

export class RoundBlock1Directive implements OnInit {
	@Input() appRoundBlock1: string = '';
	
	constructor(
		private elmRef: ElementRef, 
		private renderer: Renderer2
	) {}
	
	ngOnInit() {
		let roundVal = `${this.appRoundBlock1}`;
		this.renderer.setStyle(this.elmRef.nativeElement, 'border-radius', roundVal);
	}
}