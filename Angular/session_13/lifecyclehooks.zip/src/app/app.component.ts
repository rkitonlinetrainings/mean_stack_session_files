import { Component, OnInit, AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, DoCheck, OnChanges, OnDestroy, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  title = 'lifecyclehooks';
  displayChild: boolean = false;
  
  // constructor
  constructor() {
	  console.log("AppComponent: constructor()");
  }
  
  // toggle user defined method - will be executed when user clicks on button (or) link
  toggle() {
	  this.displayChild = !this.displayChild;
  }
  
  // onchanges
  ngOnChanges() {
	  console.log("AppComponent: ngOnChanges()");
  }
  
  // oninit
  ngOnInit() {
	  console.log("AppComponent: ngOnInit()");
  }
  
  // docheck 
  ngDoCheck() {
	  console.log("AppComponent: ngDoCheck()");
  }
  
  // aftercontentinit
  ngAfterContentInit() {
	  console.log("AppComponent: ngAfterContentInit()");
  }
  
  // aftercontentchecked
  ngAfterContentChecked() {
	  console.log("AppComponent: ngAfterContentChecked()");
  }
  
  // afterviewinit
  ngAfterViewInit() {
	  console.log("AppComponent: ngAfterViewInit()");
  }
  
  // afterviewchecked
  ngAfterViewChecked() {
	  console.log("AppComponent: ngAfterViewChecked()");
  }
  
  // ondestroy
  ngOnDestroy() {
	  console.log("AppComponent: ngOnDestroy()");
  }
  
}
