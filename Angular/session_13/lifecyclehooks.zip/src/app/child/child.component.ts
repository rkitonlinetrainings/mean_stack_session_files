import { Component, OnInit, AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, DoCheck, OnChanges, OnDestroy, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

  @Input() message = "";
	
  // constructor
  constructor() {
	  console.log("ChildComponent: constructor()");
  }
  
  // onchanges
  ngOnChanges() {
	  console.log("ChildComponent: ngOnChanges()");
  }
  
  // oninit
  ngOnInit() {
	  console.log("ChildComponent: ngOnInit()");
  }
  
  // docheck 
  ngDoCheck() {
	  console.log("ChildComponent: ngDoCheck()");
  }
  
  // aftercontentinit
  ngAfterContentInit() {
	  console.log("ChildComponent: ngAfterContentInit()");
  }
  
  // aftercontentchecked
  ngAfterContentChecked() {
	  console.log("ChildComponent: ngAfterContentChecked()");
  }
  
  // afterviewinit
  ngAfterViewInit() {
	  console.log("ChildComponent: ngAfterViewInit()");
  }
  
  // afterviewchecked
  ngAfterViewChecked() {
	  console.log("ChildComponent: ngAfterViewChecked()");
  }
  
  // ondestroy
  ngOnDestroy() {
	  console.log("ChildComponent: ngOnDestroy()");
  }

}
