import { LoggingService } from "./logging.service";
import { EventEmitter, Injectable } from "@angular/core";

@Injectable()
export class AccountService {
	accounts: any = [
		{
			name: "master account", 
			status: "active"
		}, 
		{
			name: "test account", 
			status: "inactive"
		}, 
		{
			name: "hiddent account",
			status: "hidden"
		}
	];
	
	statusUpdated: any = new EventEmitter<string>();
	constructor(private _loggingService: LoggingService) {}
	
	addAccount(name: string, status: string) {
		this.accounts.push({name: name, status: status});
		this._loggingService.logStatusChange(status);
	}
	
	updateStatus(id: number, status: string) {
		this.accounts[id].status = status;
		this._loggingService.logStatusChange(status);
	}
}