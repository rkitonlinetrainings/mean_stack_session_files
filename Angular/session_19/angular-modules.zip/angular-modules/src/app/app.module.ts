import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { StudentModule } from '../student/student.module';

import { StudentComponent } from '../student/student.component';

const routes: Routes = [
  {
    path: '',
    component: StudentComponent,
  },
];

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    StudentModule,
    RouterModule.forRoot(routes),
  ],
  declarations: [AppComponent, HelloComponent],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
