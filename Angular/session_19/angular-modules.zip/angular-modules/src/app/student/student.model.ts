export class Student {
  id: Number;
  name: String;
  enrollno: Number;
  college: String;
  university: String;
}
