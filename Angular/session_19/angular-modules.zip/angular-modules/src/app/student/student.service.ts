import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Student } from './student.model';

@Injectable()
export class StudentService {
  constructor() {}

  students: Student[] = [
    {
      id: 1,
      name: 'amit',
      enrollno: 532746,
      college: 'wp eng., college',
      university: 'mit',
    },
    {
      id: 2,
      name: 'jalpa',
      enrollno: 864422,
      college: 'niuoa college',
      university: 'wor',
    },
    {
      id: 3,
      name: 'mykta',
      enrollno: 974525,
      college: 'adam st., college',
      university: 'bits',
    },
  ];

  public getStudents(): any {
    const studentsObservable = new Observable((observer) => {
      setTimeout(() => {
        observer.next(this.students);
      }, 1000);
    });
    return studentsObservable;
  }
}
