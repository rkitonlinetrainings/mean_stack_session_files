import { Component } from "@angular/core";

@Component({
    selector: "app-contactus", 
    templateUrl: "./contactus.component.html", 
    styleUrls: [ "./contactus.component.css" ]
})

export class ContactUsComponent {
    title: string = "Contact Us!";

    firstName: string;
    lastName: string;
    age: number;
    status: boolean;

    constructor() {
        this.firstName = "john";
        this.lastName = "paul";
        this.age = 52;
        this.status = true;
    }
}