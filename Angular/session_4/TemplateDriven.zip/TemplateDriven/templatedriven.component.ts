import { Component } from "@angular/core";

@Component({
    selector: "app-templatedriven", 
    templateUrl: "./templatedriven.component.html", 
    styleUrls: [ "./templatedriven.component.css" ]
})

export class TemplateDrivenComponent {
    title: string = "Template Drive Form!";

    userName: string;
    emailAddress: string;
    mobileNumber: string;
    password: string;

    constructor() {
        this.userName = "";
        this.emailAddress = "";
        this.mobileNumber = "";
        this.password = "";
    }

    onSubmit(tmpDrvnFrm: any) {
        console.log(tmpDrvnFrm);
    }
}