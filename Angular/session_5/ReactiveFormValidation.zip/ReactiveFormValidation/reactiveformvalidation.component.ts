import { Component } from '@angular/core';

@Component({
  selector: 'app-reactiveformvalidation',
  templateUrl: './reactiveformvalidation.component.html',
  styleUrls: ['./reactiveformvalidation.component.css']
})
export class ReactiveFormValidationComponent {
  title = 'Reactive Form Validation!';

  submitted = false;

  City: any = [
    "Florida", 
    "South Dakota", 
    "Tennesse", 
    "Michigan"
  ];

  constructor() {}

  
}
