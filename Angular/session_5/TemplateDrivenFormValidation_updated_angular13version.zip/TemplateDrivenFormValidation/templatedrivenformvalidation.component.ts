import { Component } from '@angular/core';

export class User {
  public name: string;
  public email: string;
  public password: string;
  public hobbies: string;    
}

@Component({
  selector: 'app-templatedrivenformvalidation',
  templateUrl: './templatedrivenformvalidation.component.html',
  styleUrls: ['./templatedrivenformvalidation.component.css']
})

export class TemplateDrivenFormValidationComponent {
  title = 'Template Driven Formm Validation!';

  model = new User();

  Hobbies: string[] = [
    "acrobatics", 
    "acting", 
    "boxing", 
    "scating", 
    "reading"
  ];

  constructor() {}

  onSubmit(form) {
    console.log(form.value);
  }

}
