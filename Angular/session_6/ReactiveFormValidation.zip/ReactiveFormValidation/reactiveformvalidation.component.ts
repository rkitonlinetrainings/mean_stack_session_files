import { Component } from '@angular/core';
import { FormBuilder, FormArray, Validators } from '@angular/forms';


@Component({
  selector: 'app-reactiveformvalidation',
  templateUrl: './reactiveformvalidation.component.html',
  styleUrls: ['./reactiveformvalidation.component.css']
})
export class ReactiveFormValidationComponent {
  title = 'Reactive Form Validation!';

  submitted = false;

  City: any = [
    "Florida", 
    "South Dakota", 
    "Tennesse", 
    "Michigan"
  ];

  constructor(
    public fb: FormBuilder, 
  ) {}

  /* registration form  */
  registrationForm = this.fb.group({
    file: [null], 
    
    fullName: this.fb.group({
      firstName: ["", [Validators.required, Validators.minLength(4), Validators.pattern('^[a-zA-Z]*((-|\s)*[a-zA-Z])*$')]], 
      lastName: ["", [Validators.required]]
    }),

    email: ["", [Validators.required, Validators.pattern()]], 

    phoneNumber: ["", [Validators.required, Validators.maxLength(10), Validators.pattern()]], 

    address: this.fb.group({

    }), 

    gender: ['male'], 

    passwordValidation: this.fb.group({
      
    })

  })
  
}
