import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  Products = [
    {
      id: 1, 
      name: "t-Shirt", 
      description: "lets have a brief descr., about t-Shirt"
    }, 
    {
      id: 2, 
      name: "Lenovo S234 Laptop", 
      description: "lets have a brief descr., about Lenovo S234 Laptop"
    },
    {
      id: 3, 
      name: "LG Washing Machine", 
      description: "lets have a brief descr., about LG Washing Machine"
    }
  ];
  
  constructor() { }

  ngOnInit(): void {
  }

}
