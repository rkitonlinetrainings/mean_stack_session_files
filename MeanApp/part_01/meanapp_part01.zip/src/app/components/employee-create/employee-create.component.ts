import { Component, OnInit, NgZone } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from "../../service/api.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent implements OnInit {
  submitted = false;
  employeeForm: FormGroup;
  EmployeeProfile: any = ["HR", "Finance", "Sales Executive", "Administrator"];

  constructor(
    public fb: FormBuilder, 
    private router: Router, 
    private ngZone: NgZone, 
    private apiService: ApiService
  ) { }

  ngOnInit() {
  }

}
